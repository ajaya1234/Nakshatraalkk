
import React from 'react'
import Header1 from './Header1'
import Footer from './Footer'
import Mahurat_content from './Mahurat_content'

const Mahurt = () => {
  return (
    <>
    <div>
<Header1/>
<Mahurat_content/>
<br/>
<br/>
<Footer/>
    </div>
    </>
  )
}

export default Mahurt