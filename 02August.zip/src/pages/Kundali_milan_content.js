import { Link } from 'react-router-dom'
import React from 'react'

const Kundali_milan_content = () => {
  return (
    <>
      <section>
     <div class="container-fluid-lg">

                 <div _ngcontent-serverapp-c87="" class="faq_about_aries_horoscope"><div _ngcontent-serverapp-c87="" class="container"><h2 _ngcontent-serverapp-c87="" class="heading_seo_content_headline_chinese_horoscope" style={{texTAlign: "center"}}>Kundli Matching : Kundli Gun Milan</h2>
                <div _ngcontent-serverapp-c87="" class="" style={{paddingTop: "10px"}}>
                <p>Every human being who walks this earth brings with themselves their own set of energies. And each of these energy fields is governed by certain planets and zodiac signs. As a whole different person, the energy field that you entertain ought to be completely different from others. Or to simplify, your energies might not be compatible with others, and this what makes you and any other person you meet, different.</p>

                    <p>Horoscope matching, also known as Kundli matching in Vedic astrology, considers both; the position of the planets at the time of your birth and their current positions to find how compatible two people are for each other. Kundli matching is necessary to find if the position of the planets is likely or unlikely. For example, if Rahu is poised negatively (Rahu Mahadasha) in one’s Rashi, it is not the best time for them to get married. Similarly, the Kundli matching process can help find if the girl or the boy is Mangalik or not? And in case one of them is, your kundli helps in highlighting how one’s Managalik dosha will affect the other person.</p>

                    

                    <p><strong>Kundli Milan - A Friend Or A Foe?</strong></p>

                    <p>However, the world, in recent times, has grown up to develop a very wrong perception about Kundli matching (match making). Couples, especially the ones who dream of a love marriage, find Kundli matching as a hurdle in their relationship. Many of them are scared of the questions that would arise if their kundlis don't match and thus find ways to skip the gun milan ritual. However, this perception of the couples about kundli matching is nothing but merely wrong facts aka half baked knowledge that have been forced into their minds.</p>
                    <p>However, the world, in recent times, has grown up to develop a very wrong perception about Kundli matching (match making). Couples, especially the ones who dream of a love marriage, find Kundli matching as a hurdle in their relationship. Many of them are scared of the questions that would arise if their kundlis don't match and thus find ways to skip the gun milan ritual. However, this perception of the couples about kundli matching is nothing but merely wrong facts aka half baked knowledge that have been forced into their minds.</p>

                    <p><strong>What happens during Kundli milan?</strong></p>

                    <p>The eight parameters or categories among which the points have been divided are:-</p>
                    <ul>
                             <li>
                            <p><strong>Varna</strong> - it is the classification of people in four categories namely Brahmin, Kshatriya, Vaishya and Shudra.</p>
                            </li>
                            <li>
                            <p><strong>Vashya</strong> - the Vashya denotes the power or dominance in Vedic astrology. Vahsya classifies a person into five types – Human, Wild Animals, Small animals, Waterborne animals and Insect.</p>
                            </li>
                            <li>
                            <p><strong>Tara</strong> - it is used to denote the birth star compatibility of the person.</p>
                            </li>
                            <li>
                            <p><strong>Yoni</strong> - is the sexual compatibility the two people would share with each other.</p>
                            </li>
                            <li>
                            <p><strong>Rasyadhipati</strong> - This defines who is the Lord of the zodiac.</p>
                            </li>
                            <li>
                            <p><strong>Gana</strong> - The three Ganas in Astrology are; Dev, Manav and Rakshasa.</p>
                            </li>
                            <li>
                            <p><strong>Rashi</strong> - This category denotes love that the two people would share. The category takes into account the exact position of the Moon in the bride’s and groom’s horoscope.</p>
                            </li>
                            <li>
                            <p><strong>Nandi</strong> - Nadi Koot is related to the health of the bride and the groom. The three Nadis in astrology are Vata (air), Pitta (bile) and Kappa (phlegm).</p>
                            </li>
                        </ul>

                    <p><strong>How to avail kundli matching service online?</strong></p>

                    <p>To avail kundli matching service online, you can simply log in to the <a href="index-2.html">NakshatraTalk</a> &nbsp;app and find the horoscope matching online option on the same. Once you click on it, all you need to enter are details about both the girl and the boy, and once you have entered all the details correctly, we would match the kundlis for you. Moreover, you can <a href="shop-top-filter1.html">chat with astrologers online</a> Or <a href="shop-top-filter1.html">talk to astrologers</a> for kundali matching.</p>

                   

                   
                    </div>
                    {/* <!----> */}
                </div>
            </div>
          </div>
    </section>

    {/* <!-- Discount Section Start --> */}
   
    {/* <!-- Discount Section End --> */}

    {/* <!-- Product Section Start --> */}
    <section>
        <div class="container-fluid-lg">
            <div class="title" style={{padding: "5px"}}>
                <div style={{textAlign: "center"}}>
                <h2>Horoscope Matching - FAQs</h2>
                <h3>All you need to know about Guna Milan (Kundli Milan)</h3>
                </div>
                <p><strong>How many Gunas must at least match for a successful marriage?</strong></p>
                <p>At least 18 gunas must match for the couple if they wish to witness a long and hurdle-free marriage. However, for couples for whom 18 gunas do not match can too get married, but it is advised that they firstly, must understand that they will have to work very hard in their relationship and secondly, they must talk to astrologer to find how they can make up for the gunas that don’t match.</p><br/>

                <strong>What are the most important parameters in kundli matchmaking?</strong>
                <p>As per our astrologers, Mangal dosha matching and Nandi matching are some of the most important parameters when it comes to kundli matching.</p><br/>

                <p><strong>Can I marry if kundli does not match?</strong></p>
                <p>Yes, you can marry if your kundli does not match. However, you must first talk to an astrologer to be well aware of the consequences that come along when you marry despite the horoscope not matching for you. This way, you two will be well aware of things you need to work on to make your relationship work.</p>
            </div>
            
   
            

            </div>
        
    </section>
    {/* <!-- Product Section End --> */}

   <section class="blog-section section-b-space">
        <div class="container-fluid-lg">
            <div class="row g-4">
                <div class="col-xxl-12 col-xl-12 col-lg-12 order-lg-2">
                    <div class="row g-4 ratio_65">
                         <div class="col-xxl-4 col-sm-3">
                            <div class="blog-box wow fadeInUp" data-wow-delay="0.05s">
                                <div class="blog-image">
                                <Link to="/horoscope_page">
                                        <img src="../assets/images/inner-page/km.jpg"
                                            class="bg-img blur-up lazyload" alt=""/>
                                    </Link>
                                </div>

                                <div class="blog-contain">
                                    <div >
                                    <Link to="/horoscope_page">
                                        <h3>Today's Horoscope</h3>
                                    </Link>
                                </div>
                                   
                                    <Link to="/horoscope_page">
                                        <p> Get free Aries daily horoscope prediction today online from the best astrologer. Read your Aries Zodiac Sign horoscope today! </p>
                                    </Link>
                                    
                                </div>
                            </div>
                        </div>


                        <div class="col-xxl-4 col-sm-3">
                            <div class="blog-box wow fadeInUp" data-wow-delay="0.05s">
                                <div class="blog-image">
                                <Link to="/kundali">
                                        <img src="../assets/images/inner-page/km.jpg"
                                            class="bg-img blur-up lazyload" alt=""/>
                                    </Link>
                                </div>

                                <div class="blog-contain">
                                    <div >
                                        <Link to="/kundali">
                                        <h3>Free Kundli</h3>
                                    </Link>
                                </div>
                                   
                                <Link to="/kundali">
                                        <p> Generate your free online kundli report from Astrotalk. Our Kundli software can help you predict the future for yourself by reading the birth chart. </p>
                                    </Link>
                                    
                                </div>
                            </div>
                        </div>

                        <div class="col-xxl-4 col-sm-3">
                            <div class="blog-box wow fadeInUp" data-wow-delay="0.05s">
                                <div class="blog-image">
                                    <Link to='/kundali_milan'>
                                        <img src="../assets/images/inner-page/km.jpg"
                                            class="bg-img blur-up lazyload" alt=""/>
                                    </Link>
                                </div>

                                <div class="blog-contain">
                                    <div >
                                    <Link to='/kundali_milan'>
                                        <h3>Compatibility</h3>
                                    </Link>
                                </div>
                                   
                                <Link to='/kundali_milan'>
                                        <p> Love could be confusing, but only until you haven’t found how compatible you two are for each other... </p>
                                    </Link>
                                    
                                </div>
                            </div>
                        </div>


                        <div class="col-xxl-4 col-sm-3">
                            <div class="blog-box wow fadeInUp" data-wow-delay="0.15s">
                                <div class="blog-image">
                                <Link to='/kundali_milan'>
                                       <img src="../assets/images/inner-page/km.jpg"
                                            class="bg-img blur-up lazyload" alt=""/>
                                    </Link>
                                </div>

                                <div class="blog-contain">
                                    <div >
                                    <Link to='/kundali_milan'>
                                        <h3>Kundli Matching</h3>
                                    </Link>
                                </div>
                                   
                                <Link to='/kundali_milan'>
                                        <p> Check Love Compatibility and Marriage Prediction online at Astrotalk. Get the best Horoscope and kundli matching predictions today! .</p>
                                    </Link>
                                    
                                </div>
                            </div>
                        </div>

                      

                    </div>

                  
                </div>

              
            </div>
        </div>
    </section>




    </>
  )
}

export default Kundali_milan_content