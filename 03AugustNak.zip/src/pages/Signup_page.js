import React from 'react'


import Footer from './Footer';
import Header from './Header';
import Setting from './Setting';
import Signup from './Signup';
import Header1 from './Header1';


function Signup_page() {
  return (
    <div>
      <Header1/>
     <Signup />
       <Footer/>
      <Setting /> 

    </div>
  )
}

export default Signup_page;